const express = require('express');
const bodyParser = require('body-parser');
const request = require('request');
const app = express()

const apiKey = '66a0954be7eee9aca84a8bed722ad733';

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs')

app.get('/', function (req, res) {
    res.render('index', { weather: null, error: null });
})

app.post('/', function (req, res) {
    let city = req.body.city;
    let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`

    request(url, function (err, response, body) {
        if (err) {
            res.render('index', { weather: null, error: 'Error, please try again' });
        } else {
            
            let weather = JSON.parse(body)
            console.log(weather);
            console.log(weather.weather[0].main);
            //if (weather.weather[0].main === 'Haze') {
               // res.render('haze', { weather: null, error: null });
           // }
            if (weather.main == undefined) {
                res.render('index', { weather: null, error: 'Error, please try again' });
            } else {
                let weatherText = `It's ${weather.main.temp} degrees in ${weather.name} and condition is:${weather.weather[0].description}!`;
                if (weather.weather[0].main === 'Thunderstorm') {
                    res.render('thunder', { weather: weatherText, error: null });
                } else if (weather.weather[0].main === 'Haze') {
                    res.render('haze', { weather: weatherText, error: null });
                }
                else {
                    res.render('haze', { weather: weatherText, error: null });
                }
                //res.render('index', { weather: weatherText, error: null });
            }
        }
    });
})

app.listen(3000, function () {
    console.log('Example app listening on port 3000!')
})

